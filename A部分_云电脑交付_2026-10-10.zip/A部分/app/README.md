# 韌性出行助手 · 第二階段

目前工作目錄為 `第二阶段信息/`。2026-10-10 已接通離線跨境演示：地圖選點 → 路線風險比較 → 出發時點 → Plan B → 規則解釋與情景回放。

## 啟動

```sh
npm ci
npm run dev -- --port 3100
```

開啟 http://localhost:3100/journey ，按「中環 → 福田」查看三條跨境方案。
`/` 是第一階段通勤入口，`/api/journey` 是第二階段獨立 API。

- `npm run verify`：lint、型別檢查、單元／集成測試、production build。
- `npm run probe:route`：原有路徑讀取探針。
- `npm run probe:risk`：原有風險與排序探針。
- `npm run smoke`：第一階段回歸驗收。

無需密鑰或資料庫。地圖底圖需要網絡；路線、估算與本機回退可離線運行（已載入頁面，尚非 PWA）。

## 交付與限制

詳見 [第二階段整合交付](docs/PHASE2_INTEGRATION.md) 與 [驗證記錄](docs/PHASE2_QA_2026-10-10.md)。

目前為固定走廊的演示原型，服務狀態、人流與排隊均為 fixture／規則估算。座標、跨境實時班次、歷史校準及真人測試尚未完成。到達信心為定性分級，不是準時機率。

既有文檔：`APP_README.md`（第一階段應用）、`第二阶段_团队分工工作流.md`（團隊）、`第二阶段_路径读取工作流.md`（W0–W8）、`docs/PHASE2_CONTRACTS.md`（原有契約）。
第一階段歸檔在上級 `第一阶段_归档/`，本次未修改。
