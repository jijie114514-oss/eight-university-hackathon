import type { CandidateRoute, RouteQuery } from './route';
import type { RouteMode, CrowdSignal } from './risk';
import type { RankedRoute } from './reliability';

export type JourneyScenario = 'normal' | 'heavy_rain' | 'disruption';
export interface JourneyAnalysisRequest extends RouteQuery {
  scenario: JourneyScenario;
  mode: RouteMode;
  arriveBy?: string;
}
export interface AnalyzedJourney {
  candidate: CandidateRoute;
  assessment: RankedRoute;
  crowd: CrowdSignal;
  eligible: boolean;
  exclusions: string[];
  meetsDeadline: boolean | null;
  explanation: string;
}
export interface DepartureOption {
  departAt: string;
  routeId: string | null;
  riskScore: number | null;
  etaRange: [string, string] | null;
  meetsDeadline: boolean | null;
}
export interface JourneyAnalysis {
  request: JourneyAnalysisRequest;
  routes: AnalyzedJourney[];
  recommendedRouteId: string | null;
  action: 'go' | 'hold' | 'unavailable';
  departureOptions: DepartureOption[];
  bestDeparture: DepartureOption | null;
  planB: { routeId: string; trigger: string; reason: string } | null;
  notices: string[];
  quality: 'fixture';
  sources: { label: string; url: string | null; updatedAt: string; note: string }[];
}
