import { z } from 'zod';
import { findPlace } from '@/lib/geo/places';
import { parseArriveBy } from '@/lib/time';
import { analyzeJourney } from '@/lib/journey/analysis';
import { apiError } from './errors';

const schema = z.object({
  origin: z.string().min(1).max(120), destination: z.string().min(1).max(120),
  departAt: z.string().max(40), arriveBy: z.string().max(40).optional(),
  scenario: z.enum(['normal', 'heavy_rain', 'disruption']).default('normal'),
  mode: z.enum(['fastest', 'reliable', 'less_crowded', 'balanced']).default('balanced'),
}).strict();
export async function handleJourneyRequest(raw: unknown) {
  const parsed = schema.safeParse(raw);
  if (!parsed.success) return { status: 400, body: apiError('INVALID_INPUT', '請檢查地點、時間、模式與演示情景。', parsed.error.issues.map(i => i.message)) };
  const input = parsed.data;
  const departure = parseArriveBy(input.departAt);
  const arrival = input.arriveBy ? parseArriveBy(input.arriveBy) : null;
  if (!departure.ok || (arrival && !arrival.ok) || !findPlace(input.origin) || !findPlace(input.destination) || findPlace(input.origin)?.id === findPlace(input.destination)?.id || (arrival?.ok && departure.ok && arrival.epochMs <= departure.epochMs)) {
    return { status: 400, body: apiError('INVALID_INPUT', '請選擇不同的已知起終點，並讓到達期限晚於出發時間。') };
  }
  try {
    return { status: 200, body: await analyzeJourney({ ...input, departAt: departure.iso, arriveBy: arrival?.ok ? arrival.iso : undefined }) };
  } catch {
    return { status: 500, body: apiError('INTERNAL_ERROR', '行程分析暫時無法完成，請重試。') };
  }
}
