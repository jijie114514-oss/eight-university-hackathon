# 待 A 核对的前端接口问题

状态：未发送、未确认，仅整理供团队审阅。

1. 最小回应兼容：API_CONTRACT允许附加字段缺失，但当前DecisionCard依赖primaryPlan、planBPlan、generatedFor、candidates、notices、dataSources。D可修展示默认值和锁定字段回退；A请确认继续保留可选语义。
2. C新增action、switchDeadline、basis、uncertainty未登记在附加字段表。请A确认当前类型与语义，再更新文档；D不自行改共享类型。
3. maxExtraCost=0应解释为不接受额外车费，契约中“只接受免费方案”容易误导，请A核对。
4. 离线范围：请确认是本地服务使用fixture演示，还是浏览器完全断网仍可首次打开/查询。现有NETWORK_ERROR没有浏览器端回退；QA的live未配置来源是上游回退，不能证明设备断网可用。

确认记录：日期____；确认人____；决定____；影响文件____；处理人____。
